package server.model;

import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * The type Purchase list.
 */
public class PurchaseList {
	private ArrayList<Purchase> pl=new ArrayList<Purchase>();

    /**
     * Instantiates a new Purchase list.
     *
     * @param purchaseList the purchase list
     */
    public PurchaseList(ResultSet purchaseList) {
		//travers and poplulate pl 
		
	}

}
