#!/bin/bash
# https://stackoverflow.com/questions/49937743/install-jenkins-in-ubuntu-18-04-lts-failed-failed-to-start-lsb-start-jenkins-a
sudo apt install -y openjdk-8-jre
sudo update-alternatives --config java
