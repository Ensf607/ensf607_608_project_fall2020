drop table if exists INTERNATIONAL;
drop table if exists ELECTRICAL;
drop table if exists PURCHASE;
drop table if exists ORDERLINE;
drop table if exists ORDER_;
drop table if exists CLIENT;
drop table if exists TOOL;
drop table if exists SUPPLIER;