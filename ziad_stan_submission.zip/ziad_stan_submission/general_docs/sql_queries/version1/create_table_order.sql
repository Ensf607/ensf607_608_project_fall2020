create table ORDER_
(
	OrderID int auto_increment,
	Date TIMESTAMP null,
	constraint ORDER__pk
		primary key (OrderID)
);
